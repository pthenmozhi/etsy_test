package com.db.am.bauhaus.project;

/**
 * Created by ongshir on 06/04/2017.
 */
public enum SessionVar {
    SEARCH_TEXT;
}
